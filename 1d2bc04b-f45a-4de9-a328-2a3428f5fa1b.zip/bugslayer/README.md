# 🐛 BugSlayer To-Do List

> A powerful, developer-focused task manager for tracking bugs, features, and sprints — built with pure HTML, CSS & JavaScript. Zero dependencies. Fully deployable.

![BugSlayer](https://img.shields.io/badge/BugSlayer-v1.0-6366f1?style=flat-square&logo=data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAxMDAgMTAwIj48dGV4dCB5PSIuOWVtIiBmb250LXNpemU9IjkwIj7wn5ybPC90ZXh0Pjwvc3ZnPg==)
![HTML5](https://img.shields.io/badge/HTML5-E34F26?style=flat-square&logo=html5&logoColor=white)
![CSS3](https://img.shields.io/badge/CSS3-1572B6?style=flat-square&logo=css3&logoColor=white)
![JavaScript](https://img.shields.io/badge/JavaScript-ES6+-F7DF1E?style=flat-square&logo=javascript&logoColor=black)
![License](https://img.shields.io/badge/License-MIT-22c55e?style=flat-square)

---

## ✨ Features

| Feature | Description |
|---|---|
| 🐛 **Bug Tracking** | Log bugs with title, description, priority, category, due date & tags |
| 🔴 **Priority Levels** | Critical / High / Medium / Low with color-coded borders & glow effects |
| 🏷️ **Categories** | Built-in dev categories (Bug Fix, Feature, Refactor, Testing, Docs, DevOps) + custom |
| 📅 **Due Dates** | Overdue detection, due-today alerts, due-soon warnings |
| 🔍 **Search** | Real-time full-text search across title, description, category & tags |
| 🗂️ **Filters** | All / Active / Due Today / Critical / Overdue / Completed |
| ↕️ **Sorting** | Sort by date created, last updated, priority, due date, or title |
| 🔄 **Drag & Drop** | Reorder tasks by dragging cards |
| 📊 **Stats Dashboard** | Live stats: Total / Active / Completed / Overdue / Critical + progress bar |
| 🌙 **Dark / Light Mode** | Full theme toggle with smooth CSS transitions |
| 💾 **Persistence** | All data saved to `localStorage` — survives page refreshes |
| 📦 **Export / Import** | Export tasks to JSON, import from JSON (merge, no duplicates) |
| 🎨 **Animations** | Card enter, toast slide, modal pop, drag glow, critical pulse |
| 📱 **Responsive** | Mobile-friendly with collapsible sidebar |
| ♿ **Accessible** | ARIA roles, keyboard navigation (Esc to close, Ctrl+K to search) |

---

## 🚀 Quick Start

### Option 1 — Open Directly
```bash
# Clone the repo
git clone https://github.com/YOUR_USERNAME/bugslayer.git
cd bugslayer

# Open in browser (no build step needed)
open index.html
```

### Option 2 — Local Dev Server
```bash
# Using Python
python -m http.server 8080

# Using Node.js / npx
npx serve .

# Using VS Code
# Install "Live Server" extension → Right-click index.html → Open with Live Server
```

### Option 3 — Deploy to Vercel
```bash
npm i -g vercel
vercel --prod
```

### Option 4 — Deploy to Netlify
```bash
# Drag & drop the /bugslayer folder to netlify.com/drop
# OR use CLI:
npm i -g netlify-cli
netlify deploy --prod --dir .
```

### Option 5 — Deploy to GitHub Pages
```bash
# Push to GitHub, then:
# Settings → Pages → Source: Deploy from branch → main / root
```

---

## 📁 Project Structure

```
bugslayer/
├── index.html              # Main entry point — full app shell
├── README.md               # Documentation
├── package.json            # npm metadata & deploy scripts
├── vercel.json             # Vercel deployment config
├── netlify.toml            # Netlify deployment config
├── .gitignore              # Git ignore rules
│
├── styles/
│   ├── main.css            # Design system, layout, components
│   └── animations.css      # Keyframes, transitions, motion
│
├── js/
│   ├── storage.js          # localStorage CRUD (tasks, settings, categories)
│   ├── utils.js            # Helpers: ID gen, date format, stats, export
│   ├── filters.js          # Filter / sort / search logic
│   ├── ui.js               # DOM rendering, modal, toasts, theme
│   └── app.js              # App state, business logic, event binding
│
└── assets/
    └── icons/              # (reserved for custom icons)
```

---

## 🏗️ Architecture

BugSlayer uses a **modular IIFE pattern** — each module is a self-contained Immediately Invoked Function Expression that exposes a clean public API:

```
┌─────────────┐     reads/writes    ┌─────────────────┐
│  storage.js │ ◄──────────────────► │  localStorage   │
└──────┬──────┘                      └─────────────────┘
       │ getTasks / saveTasks
       ▼
┌─────────────┐     filter/sort     ┌─────────────────┐
│   app.js    │ ──────────────────► │   filters.js    │
│  (state)    │                     └─────────────────┘
└──────┬──────┘
       │ render()
       ▼
┌─────────────┐     DOM updates     ┌─────────────────┐
│    ui.js    │ ──────────────────► │   index.html    │
└─────────────┘                     └─────────────────┘
       ▲
       │ helpers
┌─────────────┐
│   utils.js  │
└─────────────┘
```

### Data Flow
1. User action → `app.js` event handler
2. `app.js` mutates state → calls `Storage.saveTasks()`
3. `app.js` calls `render()` → `Filters.apply()` → `UI.renderTasks()`
4. UI updates DOM in one pass

---

## 🎨 Design Tokens

All visual values are CSS custom properties, making theming trivial:

```css
:root {
  --accent:         #6366f1;   /* Indigo — primary brand color */
  --priority-critical: #ef4444; /* Red */
  --priority-high:     #f97316; /* Orange */
  --priority-medium:   #f59e0b; /* Amber */
  --priority-low:      #22c55e; /* Green */
}
```

---

## ⌨️ Keyboard Shortcuts

| Shortcut | Action |
|---|---|
| `Ctrl + K` / `Cmd + K` | Focus search bar |
| `Escape` | Close modal |

---

## 📦 Task Data Schema

```json
{
  "id":          "bs_lrx7abc_xyz123",
  "title":       "Fix login null pointer exception",
  "description": "Users get 500 error on empty password.",
  "priority":    "critical",
  "category":    "Bug Fix",
  "dueDate":     "2025-01-20",
  "tags":        ["auth", "backend", "urgent"],
  "completed":   false,
  "createdAt":   "2025-01-18T10:00:00.000Z",
  "updatedAt":   "2025-01-18T10:00:00.000Z"
}
```

---

## 🧩 Extending BugSlayer

### Add a new filter
In `filters.js` → `apply()`, add a new `case`:
```js
case 'my-filter':
  result = result.filter(t => /* your condition */);
  break;
```
Then add a button in `index.html` with `data-filter="my-filter"`.

### Add a new sort option
In `filters.js` → `sort()`, add a new `case`:
```js
case 'myField':
  valA = a.myField;
  valB = b.myField;
  break;
```

### Add a new theme
Add a new `[data-theme="mytheme"]` block in `main.css` overriding the CSS variables.

---

## 🌐 Deployment Configs

### Vercel (`vercel.json`)
```json
{ "rewrites": [{ "source": "/(.*)", "destination": "/index.html" }] }
```

### Netlify (`netlify.toml`)
```toml
[build]
  publish = "."
[[redirects]]
  from = "/*"
  to   = "/index.html"
  status = 200
```

---

## 📄 License

MIT © 2025 — Free to use, modify, and deploy.

---

<p align="center">Built with ❤️ and ☕ — <strong>Slay your bugs, ship with confidence.</strong></p>